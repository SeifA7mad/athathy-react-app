export default function VendorPortal() {
  return <div>VendorPortal</div>;
}
