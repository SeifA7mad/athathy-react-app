export interface SvgProps {
  className?: string;
}
